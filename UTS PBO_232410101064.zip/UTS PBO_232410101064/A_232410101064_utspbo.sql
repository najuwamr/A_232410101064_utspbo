CREATE TABLE kontak (
id_kontak SERIAL PRIMARY KEY,
nama_kontak VARCHAR(100) NOT NULL,
email Varchar (50) not null,
noHp varchar (15) not null
);

create table pengguna(
id_user serial primary key,
nama varchar (100) not null,
username varchar (20) not null,
password varchar (15) not null
);

insert into kontak (nama_kontak, email, noHp) values
('Diana Izyan', 'dianaizym@mail.com', '2383'),
('Arthur Adhitama', 'arthurian@mail.com', '082233445566')

select * from kontak