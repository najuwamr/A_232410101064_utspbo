﻿using A_232410101064_utspbo.App.Core;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A_232410101064_utspbo.App.Context
{
    internal class AdminContext : DatabaseWrapper
    {
        private static string table = "admin";

    }
}
