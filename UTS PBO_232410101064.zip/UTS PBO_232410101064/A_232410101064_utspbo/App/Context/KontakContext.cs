﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using A_232410101064_utspbo.App.Core;
using A_232410101064_utspbo.App.Models;

namespace A_232410101064_utspbo.App.Context
{
    internal class KontakContext
    {
        public KontakContext() { }
    }
}
