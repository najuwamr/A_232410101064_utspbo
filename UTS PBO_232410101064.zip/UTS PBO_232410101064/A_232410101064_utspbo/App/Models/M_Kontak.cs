﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A_232410101064_utspbo.App.Models
{
    internal class M_Kontak
    {
        [Key]
        public int id { get; set; }
        [Required]
        public string nama_kontak { get; set; }
        [Required]
        public string email { get; set; }
        [Required]
        public string noHp { get; set; }
    }
}
