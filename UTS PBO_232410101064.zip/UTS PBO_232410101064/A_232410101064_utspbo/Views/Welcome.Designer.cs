﻿namespace A_232410101064_utspbo.Views
{
    partial class Welcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Headerwlc = new Label();
            btnRegist = new Button();
            btnLogin = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // Headerwlc
            // 
            Headerwlc.AutoSize = true;
            Headerwlc.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Headerwlc.Location = new Point(265, 38);
            Headerwlc.Name = "Headerwlc";
            Headerwlc.Size = new Size(235, 38);
            Headerwlc.TabIndex = 2;
            Headerwlc.Text = "Selamat Datang";
            // 
            // btnRegist
            // 
            btnRegist.Location = new Point(260, 244);
            btnRegist.Name = "btnRegist";
            btnRegist.Size = new Size(240, 29);
            btnRegist.TabIndex = 3;
            btnRegist.Text = "Regist";
            btnRegist.UseVisualStyleBackColor = true;
            btnRegist.Click += button1_Click;
            // 
            // btnLogin
            // 
            btnLogin.Location = new Point(260, 142);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(240, 29);
            btnLogin.TabIndex = 4;
            btnLogin.Text = "Login";
            btnLogin.UseVisualStyleBackColor = true;
            btnLogin.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(343, 201);
            label1.Name = "label1";
            label1.Size = new Size(71, 20);
            label1.TabIndex = 5;
            label1.Text = "----or----";
            // 
            // Welcome
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(btnLogin);
            Controls.Add(btnRegist);
            Controls.Add(Headerwlc);
            Name = "Welcome";
            Text = "Welcome";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Headerwlc;
        private Button btnRegist;
        private Button btnLogin;
        private Label label1;
    }
}