﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A_232410101064_utspbo.Views
{
    public partial class HalRegister : Form
    {
        public HalRegister()
        {
            InitializeComponent();
        }

        private void HalRegister_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nama = textBox1.Text;
            string username = textBox3.Text;
            string password = textBox3.Text;

            if (string.IsNullOrEmpty(username) ||string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Masukkan username dan password terlebih dahulu");
 }
            else
            {
                var daftarSuccess = daftar(username, password);
                if (daftarSuccess == 1)
                {
                    MessageBox.Show("Login berhasil!");
                    
                }
                else if (daftarSuccess == 0)
                {
                    MessageBox.Show("Username atau password salah!");
                }
            }
    }
}
